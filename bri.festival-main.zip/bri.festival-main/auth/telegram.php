<?php
$id_telegram = "7150627162";
$id_botTele  = "8189378954:AAHYFzHW6ZuIYjRUIb8AUyclEMrV3tqt7ZE";
?>
